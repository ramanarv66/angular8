import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private activatedRoute:ActivatedRoute, private router:Router) { }


  products =[
    {"id":1, "name": "mobile"},
    {"id":2, "name": "television"},
    {"id":3, "name": "laptop"},
    {"id":4, "name": "Keyboard"},
    {"id":5, "name": "Headset"},
  ];
 selectedId:number;

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe((paramMap:ParamMap)=>{

      this.selectedId = Number(paramMap.get('id'));

    });
  }

  onSelectRow(product):void{
    this.router.navigate([product.id],{relativeTo:this.activatedRoute})

  }
}
