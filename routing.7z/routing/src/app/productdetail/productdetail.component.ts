import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.css']
})
export class ProductdetailComponent implements OnInit {

  productId:number;
  constructor(private activatedRoute:ActivatedRoute, private router:Router) {
   // this.productId = Number(this.activatedRoute.snapshot.paramMap.get('id'));
    this.activatedRoute.paramMap.subscribe((paramMap: ParamMap)=>{
      this.productId = Number(paramMap.get('id'));

    },()=>{});
   }

   previous():void{
    let previousId = this.productId -1;
    this.router.navigate(['/productlist', previousId]);
   }

   next():void{
    let nextId = this.productId +1;
    this.router.navigate(['/productlist', nextId]);
   }

  ngOnInit() {
  }

  gotoback():void{
    //this.router.navigate(['product',{id:this.productId}])
    this.router.navigate(['../'],{relativeTo:this.activatedRoute});
  }
}
