import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductComponent } from './product/product.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { DepartmentComponent } from './department/department.component';
import { ProductdetailComponent } from './productdetail/productdetail.component';
import { NorouteComponent } from './noroute/noroute.component';

const routes: Routes = [
  {path:'product', component: ProductComponent},
  {path:'', component: ProductComponent},
  {path:'product/:id', component: ProductdetailComponent},
  {path:'product', component:ProductlistComponent},
  {path:'**', component: NorouteComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
