import { Component, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-noroute',
  templateUrl: './noroute.component.html',
  styleUrls: ['./noroute.component.css']
})
export class NorouteComponent implements OnInit {

  constructor(private route:ActivatedRoute) { }
  url:string;
  ngOnInit() {
 this.url = this.route.snapshot.url[0].path;
  }

}
