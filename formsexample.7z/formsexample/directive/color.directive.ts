import { Directive, ElementRef, Renderer, HostListener } from '@angular/core';

@Directive({
  selector: '[appColor]'
})
export class ColorDirective {

  constructor(private elementRef:ElementRef, private render:Renderer) {

    this.changeColor('blue');

   }

   @HostListener('click') onMouseClick(){
     this.changeColor('Green')
   }
   @HostListener('mouseover') onMouseover(){
     this.changeColor('red');
   }
   @HostListener('mouseleave') onmouseleave(){
     this.changeColor('black');
   }
   changeColor(colorname:string){
     this.render.setElementStyle(this.elementRef.nativeElement,'color',colorname);
   }
}
