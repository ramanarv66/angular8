import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-itemcomponent',
  templateUrl: './itemcomponent.component.html',
  styleUrls: ['./itemcomponent.component.css']
})
export class ItemcomponentComponent implements OnInit {

  constructor() { }
  component:string="item0component";
  ngOnInit() {
  }

  emittedData(cname:string):void{
    console.log('Component name========= ' + cname)
  }

}
