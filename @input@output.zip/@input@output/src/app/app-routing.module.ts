import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItemcomponentComponent } from './itemcomponent/itemcomponent.component';
import { Item1ComponentComponent } from './item1-component/item1-component.component';
import { Item2ComponentComponent } from './item2-component/item2-component.component';
import { Item3ComponentComponent } from './item3-component/item3-component.component';


const routes: Routes = [
  {path:'Item 0', component:ItemcomponentComponent},
  {path:'Item 1', component:Item1ComponentComponent},
  {path:'Item 2', component:Item2ComponentComponent},
  {path:'Item 3', component:Item3ComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
