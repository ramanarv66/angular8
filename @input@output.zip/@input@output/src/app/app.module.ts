import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ItemcomponentComponent } from './itemcomponent/itemcomponent.component';
import { Item1ComponentComponent } from './item1-component/item1-component.component';
import { Item2ComponentComponent } from './item2-component/item2-component.component';
import { Item3ComponentComponent } from './item3-component/item3-component.component';
import { SaveCancelComponent } from './save-cancel/save-cancel.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ItemcomponentComponent,
    Item1ComponentComponent,
    Item2ComponentComponent,
    Item3ComponentComponent,
    SaveCancelComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
