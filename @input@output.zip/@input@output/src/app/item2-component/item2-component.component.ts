import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item2-component',
  templateUrl: './item2-component.component.html',
  styleUrls: ['./item2-component.component.css']
})
export class Item2ComponentComponent implements OnInit {

  component:string="item2component";
  constructor() { }

  ngOnInit() {
  }

  handle(componentname:string){
    console.log("componentname   "+ componentname)
  }
}
