import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angulardesign';

  items:string[] = [];
  constructor(){
    for (let index = 0; index < 10; index++) {
      this.items.push("Item " + index)
      
    }
  }
}
