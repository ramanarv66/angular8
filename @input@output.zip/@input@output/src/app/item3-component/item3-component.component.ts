import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item3-component',
  templateUrl: './item3-component.component.html',
  styleUrls: ['./item3-component.component.css']
})
export class Item3ComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
