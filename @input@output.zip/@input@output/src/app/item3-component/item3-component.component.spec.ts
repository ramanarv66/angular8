import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Item3ComponentComponent } from './item3-component.component';

describe('Item3ComponentComponent', () => {
  let component: Item3ComponentComponent;
  let fixture: ComponentFixture<Item3ComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Item3ComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Item3ComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
