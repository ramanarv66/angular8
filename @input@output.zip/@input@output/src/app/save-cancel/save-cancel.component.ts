import { Component, OnInit, Input, Output } from '@angular/core';
import { Event } from '@angular/router';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-save-cancel',
  templateUrl: './save-cancel.component.html',
  styleUrls: ['./save-cancel.component.css']
})
export class SaveCancelComponent implements OnInit {

  @Input('description') description:string;
  @Output() public saveCancelEventEmitter = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }
  save(event:Event): void {
    console.log(this.description)
    console.log('SaveCancelcomponenet' + 'save')
    this.saveCancelEventEmitter.emit(this.description);
  }
  reset(): void {
    console.log('SaveCancelcomponenet' + 'reset')
  }
}
