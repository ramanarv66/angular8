import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item1-component',
  templateUrl: './item1-component.component.html',
  styleUrls: ['./item1-component.component.css']
})
export class Item1ComponentComponent implements OnInit {
  component:string="item1component";
  constructor() { }

  ngOnInit() {
  }
  emittedData(cname:string):void{
    console.log('Component name========= ' + cname)
  }

}
