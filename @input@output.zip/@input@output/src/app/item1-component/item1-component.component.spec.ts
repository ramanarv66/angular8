import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Item1ComponentComponent } from './item1-component.component';

describe('Item1ComponentComponent', () => {
  let component: Item1ComponentComponent;
  let fixture: ComponentFixture<Item1ComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Item1ComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Item1ComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
